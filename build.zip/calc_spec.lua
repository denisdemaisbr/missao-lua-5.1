calc = require 'calc';
local lu = require('luaunit');

-- class TestCalc
TestCalc = {};

function TestCalc:testAdd()
	lu.assertEquals(calc.add(1, 0), 1);
	lu.assertEquals(calc.add(1, -1), 0);
end
-- class TestWithInt

local runner = lu.LuaUnit.new();
runner:setOutputType("text");
runner:setOutputType("TAP");

os.exit( runner:runSuite() );
