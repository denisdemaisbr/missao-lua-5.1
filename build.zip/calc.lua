local function add(a, b)
	assert( type(a) == 'number' );
	assert( type(b) == 'number' )
	
	return a+b;
end

return {
	add = add
}
